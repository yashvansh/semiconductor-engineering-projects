# Semiconductor Projects Portfolio - Consolidated Summary

This repository contains three engineering portfolio projects created with synthetic, industry-realistic data:
1. SPC & DOE Optimization for Semiconductor Process (SPC_DOE_Optimization)
2. FMEA & Reliability Analysis for Fab Equipment (FMEA_Reliability)
3. Automated Visual Inspection using ML (Visual_Inspection_ML)

Each project includes datasets, Jupyter notebooks, plots, and READMEs. The Visual Inspection project was expanded with 2000 synthetic images and a tuned ML pipeline. See `Visual_Inspection_ML/data/features_expanded.csv` and `plots/tuned_model_metrics.csv` for final model metrics.

Key deliverables:
- Tuned classifier threshold and metrics saved at Visual_Inspection_ML/plots/tuned_model_metrics.csv
- Detailed fishbone diagram at FMEA_Reliability/plots/fishbone_detailed.png
- One-page PDF summary at semiconductor_projects/portfolio_summary.pdf

Usage: Open the notebooks under each project to reproduce analyses and regenerate assets.
