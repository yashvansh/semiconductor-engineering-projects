# FMEA & Reliability Analysis for Fab Equipment

## Problem Statement
Perform FMEA and Weibull reliability analysis on synthetic fab equipment failure data to prioritize improvements and reduce downtime.

## Files
- `data/dataset.csv` - synthetic dataset with Equipment_ID, Failure_Mode, Time_to_Failure_hr, Severity, Occurrence, Detection
- `notebooks/analysis.ipynb` - Jupyter notebook with RPN calculation, Weibull fits, Pareto and Fishbone diagrams
- `plots/` - contains pareto_failure_modes.png, fishbone_schematic.png, weibull_parameters.csv, RPN_summary_table.png

## How to run
1. Open `notebooks/analysis.ipynb` in Jupyter and run all cells.
2. Review `plots/` for visual outputs and `plots/weibull_parameters.csv` for estimated Weibull parameters.

## Key results (example)
Top failure mode by RPN: Electrical Fault

## Notes
Weibull parameters were estimated using median-rank linearization; for production use, use maximum likelihood fits (scipy or specialized tools).


## Updates
- Weibull MLE parameter estimates saved to `plots/weibull_parameters_mle.csv` with per-mode plots `plots/weibull_plot_<mode>.png`.
- Detailed fishbone with mitigation actions saved to `plots/fishbone_detailed_mitigations.png`.
