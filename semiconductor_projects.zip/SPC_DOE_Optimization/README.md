# SPC & DOE Optimization for Semiconductor Process

## Problem Statement
Perform SPC and DOE on synthetic semiconductor process data to identify factors affecting assembly yield and propose optimized settings.

## Files
- `data/dataset.csv` - synthetic dataset with Lot_ID, Machine_ID, Operator_ID, Temperature_C, Pressure_kPa, Cycle_Time_sec, Defects, Yield_percent
- `notebooks/analysis.ipynb` - Jupyter notebook with analysis (data loading, SPC charts, capability, DOE)
- `plots/` - contains I_chart_yield.png, MR_chart_yield.png, Xbar_chart.png, R_chart.png, yield_histogram.png, capability_summary.txt, DOE_summary.txt

## How to run
1. Open `notebooks/analysis.ipynb` in JupyterLab/Notebook and run all cells. The notebook reads `data/dataset.csv`.
2. The plots will be generated into the `plots/` folder.

## Key results (summary)
Process Mean: 96.152, Std: 3.156, Cp: 0.528, Cpk: 0.406

## Notes
This project uses synthetic data. The DOE step attempts to run a full factorial-like regression using normalized continuous factors. If statsmodels is not installed, the notebook contains fallback code to run simple OLS via numpy.
